from django.shortcuts import render
from . import ml_predict
from . import text

def home(request):
    return render(request, 'index.html')

def result(request):
 #Used to get the info on result page from index .GET["name"]
    prediction = ml_predict.prediction_model()
    return render(request, 'result.html', {'prediction':prediction})

def test_result(request):
 #Used to get the info on result page from index .GET["name"]
    predict_text = text.text_model()
    return render(request, 'result_text.html', {'predict_text':predict_text})
