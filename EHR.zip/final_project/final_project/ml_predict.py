def prediction_model():
    import pickle
    import numpy as np
    import pandas as pd
    import csv
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score
    from sklearn.metrics import precision_score
    from sklearn.metrics import recall_score
    from sklearn.metrics import f1_score
    from sklearn.metrics import confusion_matrix
    import lightgbm as lgb

    clf = pickle.load(open('ml_model.sav','rb'))
    tr_df=pd.read_csv("diab.csv")

    tr_df["output"] = tr_df["output"].replace(['No_Diabetes','Prediabetis','Type1','Type2'],[0,1,2,3])

    tr_X=tr_df.iloc[:,:-1]
    tr_y=tr_df.iloc[:,-1:]

    tr_Xtrain,tr_Xtest,tr_ytrain,tr_ytest = train_test_split(tr_X,tr_y,test_size = 0.2,random_state = 0)

    d_train = lgb.Dataset(tr_Xtrain, label=tr_ytrain)

    params = {}
    params['learning_rate'] = 0.003
    params['boosting_type'] = 'gbdt'
    params['objective'] = 'multiclass'
    params['metric'] = 'multi_logloss'
    params['num_class'] = 4
    params['sub_feature'] = 0.5
    params['num_leaves'] = 200
    params['min_data'] = 50
    params['max_depth'] = 10

    clf = lgb.train(params, d_train, 500)
    tr_pred = clf.predict(tr_Xtest)

    accuracy = accuracy_score(tr_ytest, np.argmax(tr_pred, axis = 1))*100
    print("accuracy=",accuracy)

    X=pd.read_csv("diabres.csv")
    with open('diabres.csv',newline='') as f:
        reader = csv.reader(f)
        data = list(reader)

    X_new= data

    Y_new = clf.predict(X_new)

    y_new = np.argmax(Y_new, axis = 1)
    print(y_new)

    if(y_new==0):
        print('No_Diabetes')
    elif(y_new==1):
        print('Prediabetis')
    elif(y_new==2):
        print('Type1')
    else:
        print('Type2')
    return y_new
