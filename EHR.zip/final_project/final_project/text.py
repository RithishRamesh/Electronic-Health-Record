def text_model():
    import cv2
    import pandas as pd
    import pytesseract as tess
    tess.pytesseract.tesseract_cmd=r'C:\Users\Harshitha Gowda\AppData\Local\Tesseract-OCR\tesseract.exe'
#pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

    image = cv2.imread('Reportdiab.jpg', 0)
    thresh = 255 - cv2.threshold(image, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]

    x,y,w,h = 330, 274, 190, 400
    ROI = thresh[y:y+h,x:x+w]
    data = tess.image_to_string(ROI, lang='eng',config='--psm 6')
    print(data)

    #cv2.imshow('thresh', thresh)
    #cv2.imshow('ROI', ROI)
    cv2.waitKey()
    def Convert(string):
        li = list(string.split("\n"))
        return li

# Driver code
    str1 = "Geeks for Geeks"
    final=Convert(data)
    print(final)
    df=pd.DataFrame(final)
    df.to_csv('diabres.csv')
    dff=pd.read_csv('diabres.csv',header=None,index_col=False)
    dff
    dff.columns=['none','Result']
    dff
    dff=dff.iloc[1:]
    dff
    moddff= dff.drop([dff.columns[0]] ,  axis='columns')
    moddff=moddff.iloc[1:]
    moddff.to_csv('diabres.csv',index=False)
    moddff
    dd=pd.read_csv('diabres.csv')
    dd
#dd.pivot(index ='Result', columns ='Result')
    dd=dd.transpose()
    dd.to_csv('diabres.csv',index=False)
    dd=pd.read_csv('diabres.csv')
    dd
    file_variable = open('diabres.csv')
    all_lines_variable = file_variable.readlines()
    pr=all_lines_variable[2 - 1]
    print(pr)
    with open('diabres.csv','w') as ap:
        ap.write(pr)
        ap.close()
    return pr
