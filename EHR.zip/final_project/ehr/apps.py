from django.apps import AppConfig


class EhrConfig(AppConfig):
    name = 'ehr'
